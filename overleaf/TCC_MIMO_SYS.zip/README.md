# Template ATCC (ABNT) para Overleaf

Adaptação do modelo Word `TCC_3 - Modelo ATCC.docx` para LaTeX, usando a
classe `abntex2` (padrão para trabalhos acadêmicos nas normas ABNT no
Brasil).

## Como usar no Overleaf

1. Crie um projeto novo em branco no Overleaf.
2. Faça upload de todos os arquivos desta pasta (`main.tex`,
   `referencias.bib`, e a pasta `imagens/`), mantendo a mesma estrutura.
3. No menu **Settings** do projeto, defina:
   - **Compiler:** `pdfLaTeX`
   - **Main document:** `main.tex`
4. Clique em **Recompile**. O Overleaf detecta o `\bibliography{referencias}`
   e roda o `bibtex` automaticamente para gerar as referências (pode
   ser necessário clicar em "Recompile" duas vezes na primeira vez,
   para o bibtex rodar e depois o pdflatex incorporar o resultado).

## Estrutura do projeto

- `main.tex` — documento principal.
- `referencias.bib` — banco de referências em BibTeX.
- `imagens/` — `logo-unicuritiba.png` (a logo que você enviou, já
  aplicada no cabeçalho) e as duas figuras de exemplo do `.docx`
  original (`exemplo-figura1.jpg`, `exemplo-figura2.png`).

## Citação e referências: ABNT (autor-data), não Vancouver

O documento usa o pacote `abntex2cite` com a opção **`alf`**, que é o
estilo ABNT (NBR 10520/6023): citação no texto no formato
`(SOBRENOME, ano)` ou `Sobrenome (ano)`, e a lista final de
**Referências Bibliográficas em ordem alfabética** pelo sobrenome do
primeiro autor — nunca números entre colchetes como `[1]`, `[2]`
(isso seria o estilo Vancouver/numérico, usado em outras áreas, não em
ABNT).

- Citação indireta: `\cite{chave}` → `(SOBRENOME, ano)`
- Citação direta/textual: `\citeonline{chave}` → `Sobrenome (ano)`

Se ao compilar as referências aparecerem numeradas em vez de
alfabéticas, confira no início de `main.tex` se a opção do pacote
continua sendo `alf` (e não `num`, que é o estilo numérico):

```latex
\usepackage[
	alf,
	abnt-emphasize=bf,
	abnt-etal-list=0,
	abnt-etal-cite=3,
	abnt-repeated-author-omit=no
]{abntex2cite}
```

**Importante**: `abntex2cite` usa o **BibTeX clássico** como motor de
bibliografia (não o `biblatex`). Por isso o arquivo de referências é
carregado e impresso com um único comando no fim do documento:

```latex
\bibliography{referencias}
```

Não use `\addbibresource{...}` nem `\printbibliography` com esse
pacote — são comandos do `biblatex` e não existem no `abntex2cite`;
misturá-los gera erro de compilação (foi exatamente isso que causou o
texto cru aparecendo no PDF numa versão anterior deste template).
Localmente, o ciclo de compilação é
`pdflatex` → `bibtex` → `pdflatex` → `pdflatex`; no Overleaf isso roda
automaticamente ao clicar em Recompile.

## Cabeçalho, rodapé e logo

- **Margens**: 3 cm (topo/esquerda) e 2 cm (direita/base), iguais às
  do `.docx` original.
- **Cabeçalho**: a logo da Unicuritiba que você enviou já está em
  `imagens/logo-unicuritiba.png`, **centralizada e em tamanho maior**
  (altura de 2,2cm), em **todas as páginas, inclusive a capa/folha de
  rosto**, com uma linha fina abaixo (via `fancyhdr`). Se quiser trocar
  a imagem, basta substituir esse arquivo mantendo o mesmo nome.
- **Rodapé**: numeração de página no canto direito; na capa (página 1)
  não há numeração, igual ao `.docx` original.
- Ajuste tamanho (`height=2.2cm`, linha do `\newcommand{\logocabecalho}`)
  e posição (`\fancyhead[C]{...}`, troque `C` por `L`/`R` para
  esquerda/direita) em `main.tex` se precisar. Se aumentar bastante a
  logo, aumente também `headheight` no `\usepackage[...]{geometry}`
  no topo do arquivo, senão o LaTeX avisa "Overfull \vbox" no cabeçalho.

## Comentários do professor/coordenação (do .docx original)

Reproduzidos em `main.tex` como comentários de LaTeX (`%`), logo
acima do trecho correspondente — não aparecem no PDF, só orientam
enquanto você escreve:

- **Referencial teórico**: embasar cientificamente o assunto, citando
  artigos e livros; ~3 páginas em um artigo de 12 páginas.
- **Equações**: só incluir se usadas na resolução do trabalho, sempre
  explicadas no referencial teórico, numeradas, equação à esquerda e
  número à direita — o ambiente `equation` do LaTeX já faz isso
  sozinho.
- **Figuras**: sempre mencionar e explicar no texto. Fonte própria →
  "Fonte: Elaborado pelos Autores."; fonte de terceiros → citar o
  autor.
- **Tabelas**: fonte 10, Times ou Arial, preto e branco, nada em
  negrito (já configurado no exemplo).
- **Metodologia**: ~3 páginas; dividir em subtópicos; iniciar com um
  fluxograma das etapas; manter fonte legível em figuras/fluxogramas.
- **Resultados e discussões**: ~4 páginas.
- **Conclusão**: checar se responde aos objetivos propostos.
- **Agradecimentos**: lembrar de laboratórios e instituições
  parceiras.
- **Referências**: toda citação do texto precisa de entrada
  correspondente; ordem alfabética — automática com o estilo `alf`.

## Personalização

- Altere título, autores, orientador e curso no topo de `main.tex`
  (`\titulo`, `\autor`, `\orientador`, `\instituicao`).
- Adicione seções/subseções com `\section{}` / `\subsection{}`.
- Adicione referências no `referencias.bib` e cite pela chave.
